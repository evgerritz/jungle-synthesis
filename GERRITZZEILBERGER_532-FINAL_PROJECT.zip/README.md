# jungle-synthesis
Creating a cool Jungle soundscape in supercollider (532 final project)
